package com.hmap.pokedex;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PokedexApplicationTests {

	@Test
	void contextLoads() {
	}

}
